

#include <iostream>
#include "structurepokemon.h"

class Hashtablepokemon {
private:
  int bias1;
  int bias2;
  std::vector<int> hashes1;
  std::vector<int> hashes2;
  std::vector<Pokemon *> firstcucko;
  std::vector<Pokemon *> secondcucko;
  int size = 6;
  int hashFunc1(const std::string &key) {
    int hashValue = 0; // variable para almacenar el valor hash
    // itera sobre cada carácter en el nombre del Pokémon
    for (char ch : key) {
      // formula hash utilizando el valor ASCII de cada carácter
      hashValue = ((37 * hashValue + ch) + bias1) % size;
    }
    return hashValue; // devuelve el valor hash calculado
  }
  void rehash() {
    //int firstsize = size;
    // find prime
    int newsize = getfirstprimenumber();
    
    std::vector<Pokemon *> getfirsth;
    std::vector<Pokemon *> getsecondh;
    for (int i = 0; i < hashes1.size(); i++) {
      int index = hashes1[i];
      getfirsth.push_back(firstcucko[index]);
      firstcucko[index] = nullptr;
    }
    
    for (int i = 0; i < hashes2.size(); i++) {
      int index2 = hashes2[i];
      getsecondh.push_back(secondcucko[index2]);
      secondcucko[index2] = nullptr;
    }
   

    while (firstcucko.size() != newsize) {
      firstcucko.push_back(nullptr);
      secondcucko.push_back(nullptr);
    }
     

    size = newsize;

    while (getfirsth.size() != 0) {

      insertpokemon(getfirsth[0], 0, 0);
      getfirsth.erase(getfirsth.begin());
    }

    while (getsecondh.size() != 0) {
      insertpokemon(getsecondh[0], 0, 0);
      getsecondh.erase(getsecondh.begin());
    }
   

    // create new table
  }

  void insertpokemon(Pokemon *pokemon, int mode, int n_iter) {
    if (n_iter > 5) {
      rehash();
      insertpokemon(pokemon, 0, n_iter);
    }
    int firsthash = hashFunc1(pokemon->name);
    int secondhash = hashFunc2(pokemon->name);
    if (mode == 0) {
      
      

      if (firstcucko[firsthash] == nullptr) {
       
        firstcucko[firsthash] = pokemon;
        hashes1.push_back(firsthash);

        return;
      }
      Pokemon *current = firstcucko[firsthash];
      firstcucko[firsthash] = pokemon;
      insertpokemon(current, (mode + 1) % 2, n_iter + 1);
      return;

    } else {
      
      if (secondcucko[secondhash] == nullptr) {
        
        secondcucko[secondhash] = pokemon;
        hashes2.push_back(secondhash);
        return;
      }
      Pokemon *current = secondcucko[secondhash];
      insertpokemon(current, (mode + 1) % 2, n_iter + 1);
      return;
    }
  }
  int hashFunc2(const std::string &key) {
    int hashValue = 0; // variable para almacenar el valor hash
    // itera sobre cada carácter en el nombre del Pokémon
    for (char ch : key) {
      // formula hash utilizando el valor ASCII de cada carácter
      hashValue = ((37 * hashValue + ch) + bias2) % size;
    }
    return hashValue; // devuelve el valor hash calculado
  }

  bool testprime(int &prime) {
    int range = prime / 2;
  
    for (int i = 2; i < range; i++) {
      if (prime % i == 0) {
        return false;
      }
    }
    return true;
  }
  int getfirstprimenumber() {
    int base = size+1;
    while (!testprime(base)) {
      base++;
     
      
    }
    return base;
  }
  void initializehashtable() {
    int newsize = getfirstprimenumber();
    size = newsize;
    for (int i = 0; i < size; i++) {
      firstcucko.push_back(nullptr);
      secondcucko.push_back(nullptr);
    }
  }

public:
  Hashtablepokemon() {
    initializehashtable();
    bias1 = 0;
    bias2 = 3;
    
  };

  void insertpokemon(Pokemon &pokemon) { insertpokemon(&pokemon, 0, 0); return;}
  Pokemon *searchpokemon(const std::string &name) {
    int firsthash = hashFunc1(name);
    int secondhash = hashFunc2(name);
    if (firstcucko[firsthash] != nullptr) {
      if (firstcucko[firsthash]->name == name) {
        return firstcucko[firsthash];
      }
      if (secondcucko[secondhash] != nullptr) {
        if (secondcucko[secondhash]->name == name) {
          return secondcucko[secondhash];
        }
        return nullptr;
      }
    }
    return nullptr;
  }
void forcerehash(){
  rehash();
}
};