#include <fstream>
#include <iostream>
#include <time.h>
#include <vector>

using namespace std;

class shelf{


public:
vector<int> vectorp;
vector<int>vectorun;
 shelf(){
   vectorp={};
  
}
int add_toy(int xd){
  //ingreso el elemento tanto en el vector desordenado como el ordenado
  vectorun.push_back(xd);
  if (vectorp.size()==0){
    vectorp.push_back(xd);
    return 1;
  }
  //utilizo la busqueda binaria para lograr encontrar el elemento al que es mayor o menor xd
  int low,high,mid;
  low=0;
  high=vectorp.size()-1;
  while (low<=high){
    mid=(low+high)/2;
    if (xd <vectorp[mid]){
      high=mid-1;
    }
    else{
  
      low=mid+1;
      
  }}
  //si high es menor que low, implica que para el vector ordenado el elemento con indice low es menor a xd, por ende se ingresa en la posicion low, en caso contrario se ingresa en la posicion high
    if(high<low){
     pushat(vectorp,xd,low);
      return 0;
    }
    pushat(vectorp,xd,high);
    
  
  



  
  return 0;

}
void move_below(int x,int y){

  int index1,index2,i;
  index2=-1;
  index1=-1;
  i=0;
  //busco los indices de los dos elementos
  while (i<vectorun.size() && (index2==-1 || index1==-1)){
    if (vectorun[i]==y){
      index2=i;
    }
    if(vectorun[i]==x){
      index1=i;
    }
    i++;
  }
    if (index2==index1){return; }
  auto it=vectorun.begin()+index1;
    vectorun.erase(it);
    pushat(vectorun,x,1);
  
  //si no encuentra los dos elementos, o se llega a una sustitucion con indices iguales, no se hace nada
  
  
  
}
void printt(){
  for (int i=0;i<vectorun.size();i++){
    cout<<vectorun[i]<<endl;
  }
}
vector<int> *view_shelf(){
  return &vectorp;
}
//funcion para ingresar un elemento en una posicion especifica
private:
void pushat(vector<int> &vectoru,int xd,int index){
  int tempterm;
  for(int i=index;i<vectoru.size();i++){
    if (i==index){
      tempterm=vectoru[i];
      vectoru[i]=xd;
      xd=tempterm;
      continue;
    }
    tempterm=vectoru[i];
    vectoru[i]=xd;
    xd=tempterm;
  }
  vectoru.push_back(xd);
}
};

int main() {
  shelf shelf1;
  shelf1.add_toy(1);
  shelf1.add_toy(2);
  shelf1.add_toy(540);
  shelf1.move_below(540,2);
  shelf1.printt();
  return 0;
  
}