

// Implementación de los métodos

#include "bst.h"              //Para el arbol binario de mileidis
#include "pokemonhashtable.h" //Tiene la implementación de HashTable y la estructura pokemon
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

// Clase pokedex
class Pokedex {
private:
  BinarySearchTree bst;

public:
  // Inserta un pokemon en el árbol binario y en la tabla hash correspondiente
  void insertPokemon(std::string &type, Pokemon &pokemon) {
    const BinarySearchTree::PokemonEntry *node = bst.find(type);
    if (node) {
      // std::cout<<type<<std::endl;
      // si ya existe el tipo, se inseerta el pokemon en la tabla hash
      // correspondiente
      node->second->insertpokemon(pokemon);
    } else {
      // std::cout<<"xd"<<std::endl;            //Crea una nueva tabla hash para
      // este tipo y agregar el pokemon
      Hashtablepokemon *newTable = new Hashtablepokemon();
      newTable->insertpokemon(pokemon);
      bst.insert(type, newTable);
    }
  }

  // Busca un pokemon dado su tipo y nombre
  Pokemon *searchPokemon(std::string &type, std::string &name) {
    auto *node = bst.find(type);
    if (!node) {
      throw std::runtime_error("Tipo de Pokémon no encontrado en la Pokédex.");
    }
    // Busca en la tabla hash
    return node->second->searchpokemon(name);
  }

  // Imprime los tipos de pokemon disponibles dentro de la pokédex
  void printTypes() {
    std::cout << "Tipos de Pokémon disponibles en la Pokédex:" << std::endl;
    bst.printTree();
  }
};

int main() {

  Pokedex pokedex;
  std::vector<Pokemon> datab;
  // std::string nombre;
  // load data
  Pokemon p1 = {"Pikachu", "Electric", {"xd"}, true, "Electrico", "Ninguno"};
  Pokemon p2 = {"Charmander", "Fire", {"xd"}, true, "Fuego", "Ninguno"};
  // std::cout<<p1.name<<std::endl;
  // std::cout<<p2.name<<std::endl;
  cargarDesdeArchivo("pokemonns.csv", datab);
  for (int i = 0; i < datab.size(); i++) {
    // std::string type = pokemonn.type2;
    // std::cout<<type<<std::endl;

    Pokemon pokemonn = datab[i];
    std::string type = pokemonn.type2;
    // std::cout<<"name"<<pokemonn.name<<std::endl;

    pokedex.insertPokemon(type, pokemonn);
  }
  // pokedex.printTypes();
  // std::string type ="grass";
  // std::string name="Bulbasaur";
  // Pokemon *pokemon=pokedex.searchPokemon(type,name);
  // std::cout<<pokemon->name<<std::endl;
  // search pokemon
  // Pokemon *pokemon = pokedex.searchPokemon("Fire","Charmander");

  // Aquí incide lo de la base de datos, solo van a ser ejemplos de como
  // funcionaría insertar los pokemones

  // Pokemon p1 = {"Pikachu", "Electricidad", {"Impactrueno", "Agilidad"}, true,
  // "Eléctrico", "Ninguno"}; Pokemon p2 = {"Charmander", "Fuego", {"Llamarada",
  // "Garra Dragón"}, true, "Fuego", "Ninguno"}; Pokemon p3 = {"Squirtle",
  // "Agua", {"Pistola Agua", "Caparazón"}, true, "Agua", "Ninguno"};
  // std::string type= "Electricidad";

  // pokedex.insertPokemon(type, p1);
  // pokedex.insertPokemon("Fuego", p2);
  // pokedex.insertPokemon("Agua", p3);

  // Mostrar lostipos disponibles
  // pokedex.printTypes();

  // se busca el pokemon

  return 0;
}

// Funciones de prueba
